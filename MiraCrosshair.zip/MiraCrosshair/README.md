# Mira Crosshair 2.0

App Android (Kotlin) con Shizuku. Funciones:
- Mira (crosshair) sobre otras apps: 5 estilos, color, opacidad, tamaño, grosor y posición.
- FPS en pantalla (solo números: color, tamaño, opacidad y posición ajustables).
- Panel "Más detalles": FPS, jank, CPU, temperatura de batería, power (mW), mini gráfico de FPS y RAM.
- Táctil: long_press_timeout y multi_press_timeout con valores fijos, avisos y botón de restaurar.
- Perfiles de rendimiento: ahorro de batería, predeterminado y alto rendimiento.
- Liberar RAM (am kill-all).
- Cerrar apps: lista con buscador, filtros y "Seleccionar todas" (am force-stop).
- Al abrir la app exige Shizuku activo y con permiso.

## Actualizar tu app desde GitHub (desde el celular)
1. Abre tu repositorio MiraCrosshair en el navegador.
2. Ve a: github.com/TU_USUARIO/MiraCrosshair/upload/main
3. Sube este zip con el MISMO nombre (MiraCrosshair.zip): reemplaza al anterior.
4. Commit changes. En la pestaña Actions se compila solo (unos 5 minutos).
5. Descarga MiraCrosshair-apk desde Artifacts y reinstala el APK (se actualiza encima).

## Notas
- Los FPS y el jank se calculan con SurfaceFlinger vía Shizuku: son aproximados.
- Con el panel apagado no se mide nada ni queda ningún proceso corriendo.
- Android 12+: la opacidad máxima visible de las superposiciones es 80 %.
