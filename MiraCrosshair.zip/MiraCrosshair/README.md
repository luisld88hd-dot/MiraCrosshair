# Mira Crosshair

App Android (Kotlin) que dibuja una mira sobre otras apps.
- Color, opacidad, tamaño, grosor y 5 estilos
- Posición ajustable (sliders + botones de 1 px)
- Shizuku para evitar que el sistema cierre la app

## Compilar el APK

### Opción A: Android Studio (PC)
1. Descomprime el proyecto y ábrelo con *File > Open*.
2. Espera a que sincronice Gradle.
3. *Build > Build APK(s)*. Sale en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B: GitHub (sin instalar nada)
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (incluida `.github`).
2. Pestaña *Actions* > *Build APK* > espera a que termine.
3. Descarga `MiraCrosshair-apk` desde *Artifacts*, descomprime y obtén `app-debug.apk`.

## Usar
1. Instala el APK (permite "instalar apps desconocidas").
2. Instala Shizuku desde Play Store e inícialo (depuración inalámbrica, o ADB desde PC).
3. En la app: da el permiso de superposición, toca "Conectar con Shizuku" y luego "Proteger app ahora".
4. Ajusta la mira con la vista previa y toca ENCENDER MIRA. Los cambios se ven en vivo sobre el juego.

## Notas
- En Android 12+ la opacidad máxima visible es 80 %: con más, Android bloquea los toques al juego.
- Sin ícono personalizado (usa el predeterminado del sistema).
