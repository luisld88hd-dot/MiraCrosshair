package com.mira.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View

/** Solo el número de FPS. */
class FpsView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var text = "--"

    var cfg: FpsCfg = FpsCfg()
        set(v) {
            field = v
            applyPaint()
            requestLayout()
            invalidate()
        }

    init {
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        applyPaint()
    }

    private fun applyPaint() {
        paint.color = cfg.color
        paint.alpha = cfg.alpha
        paint.textSize = cfg.sizeSp * density
    }

    fun setValue(fps: Int) {
        val t = if (fps < 0) "--" else fps.toString()
        if (t != text) {
            text = t
            invalidate()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val fm = paint.fontMetrics
        val w = (paint.measureText("000") + 12 * density).toInt()
        val h = (fm.descent - fm.ascent + 8 * density).toInt()
        setMeasuredDimension(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        val fm = paint.fontMetrics
        val tw = paint.measureText(text)
        canvas.drawText(text, (width - tw) / 2f, 4 * density - fm.ascent, paint)
    }
}
