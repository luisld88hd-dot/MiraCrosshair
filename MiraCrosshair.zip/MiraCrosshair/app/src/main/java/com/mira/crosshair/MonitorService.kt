package com.mira.crosshair

import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager

/** Dibuja el número de FPS y/o el panel de detalles. Solo mide mientras alguno esté encendido. */
class MonitorService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.mira.crosshair.STOP_MONITOR"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var fpsView: FpsView? = null
    private var fpsLp: WindowManager.LayoutParams? = null
    private var detView: DetailsView? = null
    private var detLp: WindowManager.LayoutParams? = null

    private var thread: HandlerThread? = null
    private var sampler: Sampler? = null
    @Volatile private var needDetails = false
    @Volatile private var active = false

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && (key.startsWith("fps_") || key.startsWith("det_"))) reconcile()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Notif.start(this, 2, Notif.build(this, "Monitor activo",
            Intent(this, MonitorService::class.java).setAction(ACTION_STOP)))
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
        reconcile()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setFlag(this, "fps_on", false)
            Prefs.setFlag(this, "det_on", false)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
        stopSampling()
        hideFps()
        hideDet()
        running = false
        super.onDestroy()
    }

    private fun reconcile() {
        val fOn = Prefs.flag(this, "fps_on")
        val dOn = Prefs.flag(this, "det_on")
        if (!fOn && !dOn) {
            stopSelf()
            return
        }
        if (fOn) showFps() else hideFps()
        if (dOn) showDet() else hideDet()
        needDetails = dOn
        startSampling()
    }

    private fun params(x: Int, y: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = y
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= 31) lp.alpha = 0.8f
        return lp
    }

    private fun showFps() {
        val cfg = Prefs.loadFps(this)
        var v = fpsView
        if (v == null) {
            v = FpsView(this)
            v.cfg = cfg
            val lp = params(cfg.x, cfg.y)
            wm.addView(v, lp)
            fpsView = v
            fpsLp = lp
        } else {
            v.cfg = cfg
            val lp = fpsLp ?: return
            lp.x = cfg.x
            lp.y = cfg.y
            runCatching { wm.updateViewLayout(v, lp) }
        }
    }

    private fun showDet() {
        val cfg = Prefs.loadDet(this)
        var v = detView
        if (v == null) {
            v = DetailsView(this)
            v.setCfg(cfg)
            val lp = params(cfg.x, cfg.y)
            wm.addView(v, lp)
            detView = v
            detLp = lp
        } else {
            v.setCfg(cfg)
            val lp = detLp ?: return
            lp.x = cfg.x
            lp.y = cfg.y
            runCatching { wm.updateViewLayout(v, lp) }
        }
    }

    private fun hideFps() {
        fpsView?.let { runCatching { wm.removeView(it) } }
        fpsView = null
        fpsLp = null
    }

    private fun hideDet() {
        detView?.let { runCatching { wm.removeView(it) } }
        detView = null
        detLp = null
    }

    private fun startSampling() {
        if (thread != null) return
        val t = HandlerThread("mira-metrics")
        t.start()
        thread = t
        val h = Handler(t.looper)
        val sm = Sampler(this)
        sampler = sm
        active = true
        h.post(object : Runnable {
            override fun run() {
                if (!active) return
                val s = try {
                    sm.sample(needDetails)
                } catch (e: Throwable) {
                    null
                }
                if (s != null) {
                    main.post {
                        fpsView?.setValue(s.fps, s.approx)
                        detView?.push(s)
                    }
                }
                if (active) h.postDelayed(this, 1000)
            }
        })
    }

    private fun stopSampling() {
        active = false
        sampler?.close()
        thread?.quitSafely()
        thread = null
        sampler = null
    }
}
