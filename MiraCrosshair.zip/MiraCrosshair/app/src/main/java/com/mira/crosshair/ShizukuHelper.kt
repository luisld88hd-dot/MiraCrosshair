package com.mira.crosshair

import rikka.shizuku.Shizuku

object ShizukuHelper {

    /** Aplica ajustes para que Android no cierre la app y permite la superposición. */
    fun protect(pkg: String): String {
        val cmds = listOf(
            "cmd deviceidle whitelist +$pkg",
            "cmd appops set $pkg RUN_IN_BACKGROUND allow",
            "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow",
            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "am set-standby-bucket $pkg active"
        )
        return cmds.joinToString("\n\n") { c ->
            val res = try {
                exec(c).ifBlank { "OK" }
            } catch (e: Throwable) {
                "Error: ${e.message}"
            }
            "> $c\n$res"
        }
    }

    // Shizuku.newProcess es privado en las versiones recientes: se llama por reflexión.
    private fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        return (out + err).trim()
    }
}
