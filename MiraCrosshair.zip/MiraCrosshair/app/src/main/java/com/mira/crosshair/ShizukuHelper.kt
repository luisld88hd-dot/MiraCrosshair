package com.mira.crosshair

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.lang.reflect.Method

object ShizukuHelper {
    const val NOT_RUNNING = 0
    const val NEEDS_PERMISSION = 1
    const val READY = 2

    fun state(): Int = try {
        when {
            !Shizuku.pingBinder() -> NOT_RUNNING
            Shizuku.isPreV11() -> NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> READY
            else -> NEEDS_PERMISSION
        }
    } catch (e: Throwable) {
        NOT_RUNNING
    }

    // Shizuku.newProcess es privado en las versiones recientes: se llama por reflexión.
    private val newProcess: Method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun spawn(cmd: Array<String>): Process = newProcess.invoke(null, cmd, null, null) as Process

    /** Ejecuta un comando y devuelve su salida (bloquea: llamar desde un hilo). */
    fun exec(cmd: String): String {
        return try {
            val p = spawn(arrayOf("sh", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim()
        } catch (e: Throwable) {
            "Error: ${e.message}"
        }
    }

    fun getSetting(ns: String, key: String): String = exec("settings get $ns $key").trim()

    /** Evita que Android cierre la app y permite la superposición. */
    fun protect(pkg: String): String {
        val cmds = listOf(
            "cmd deviceidle whitelist +$pkg",
            "cmd appops set $pkg RUN_IN_BACKGROUND allow",
            "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow",
            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "am set-standby-bucket $pkg active"
        )
        return cmds.joinToString("\n\n") { c ->
            val res = exec(c)
            "> $c\n" + res.ifBlank { "OK" }
        }
    }
}
