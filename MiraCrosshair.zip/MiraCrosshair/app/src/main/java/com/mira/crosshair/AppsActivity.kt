package com.mira.crosshair

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import kotlin.concurrent.thread

/** Lista de apps para cerrar del todo con "am force-stop". */
class AppsActivity : GuardedActivity() {

    private class Item(
        val pkg: String,
        val label: String,
        val system: Boolean,
        val locked: Boolean,    // protegida: no se puede seleccionar
        val skipAll: Boolean    // no entra en "Seleccionar todas"
    )

    private class Row(
        val view: LinearLayout,
        val icon: ImageView,
        val name: TextView,
        val sub: TextView,
        val check: CheckBox
    )

    private val all = ArrayList<Item>()
    private val shown = ArrayList<Item>()
    private val selected = HashSet<String>()
    private var filter = 0     // 0 todas, 1 instaladas, 2 sistema
    private var query = ""
    private var closing = false

    private lateinit var list: ListView
    private lateinit var tvCount: TextView
    private lateinit var btnClose: Button
    private val adapter = Adapter()
    private val icons = LruCache<String, Drawable>(60)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = Prefs.sp(this).getStringSet("close_sel", null)
        if (saved != null) selected.addAll(saved)
        setContentView(build())
        loadApps()
    }

    // ------------------------------------------------------------- UI

    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@AppsActivity, 12), Ui.dp(this@AppsActivity, 12),
                Ui.dp(this@AppsActivity, 12), Ui.dp(this@AppsActivity, 8))
        }
        root.addView(Ui.title(this, "Cerrar apps"))
        root.addView(
            Ui.note(
                this,
                "Cierra del todo las apps marcadas (am force-stop). No te avisarán nada hasta que las abras " +
                    "de nuevo. Las apps protegidas no se pueden marcar."
            )
        )

        val search = EditText(this).apply {
            hint = "Buscar app…"
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString() ?: ""
                    applyFilter()
                }
            })
        }
        root.addView(search, Ui.mw())

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Todas las apps", "Solo instaladas", "Solo del sistema")
        )
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != filter) {
                    filter = pos
                    applyFilter()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner, Ui.mw())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(this, "Seleccionar todas") { selectAll() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.button(this, "Desmarcar") { clearAll() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row, Ui.mw())

        tvCount = TextView(this)
        root.addView(tvCount)

        list = ListView(this)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val it = shown[pos]
            if (it.locked) {
                Ui.toast(this, "Protegida: cerrarla podría dejar el sistema inestable")
            } else {
                if (!selected.add(it.pkg)) selected.remove(it.pkg)
                persist()
                adapter.notifyDataSetChanged()
                updateCount()
            }
        }
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        btnClose = Ui.button(this, "Cerrar seleccionadas") { confirmClose() }
        root.addView(btnClose, Ui.mw())
        return root
    }

    private fun newRow(): Row {
        val c = this
        val v = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(c, 4), Ui.dp(c, 6), Ui.dp(c, 4), Ui.dp(c, 6))
        }
        val icon = ImageView(c)
        v.addView(icon, LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)))
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val name = TextView(c).apply { textSize = 15f }
        val sub = TextView(c).apply {
            textSize = 11f
            setTextColor(Color.parseColor("#A0A0A0"))
        }
        col.addView(name)
        col.addView(sub)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(Ui.dp(c, 10), 0, Ui.dp(c, 6), 0)
        v.addView(col, lp)
        val check = CheckBox(c).apply {
            isClickable = false
            isFocusable = false
        }
        v.addView(check)
        val row = Row(v, icon, name, sub, check)
        v.tag = row
        return row
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView?.tag as? Row) ?: newRow()
            val item = shown[position]
            row.name.text = item.label
            var sub = item.pkg
            if (item.system) sub += " · sistema"
            if (item.locked) sub += " · protegida"
            else if (item.skipAll) sub += " · fuera de «Seleccionar todas»"
            row.sub.text = sub
            row.check.isChecked = selected.contains(item.pkg)
            row.check.isEnabled = !item.locked
            row.view.alpha = if (item.locked) 0.5f else 1f
            var ic = icons.get(item.pkg)
            if (ic == null) {
                ic = try {
                    packageManager.getApplicationIcon(item.pkg)
                } catch (e: Exception) {
                    packageManager.defaultActivityIcon
                }
                icons.put(item.pkg, ic)
            }
            row.icon.setImageDrawable(ic)
            return row.view
        }
    }

    // ------------------------------------------------------------- Datos

    private fun lockedPackages(): Set<String> {
        val s = HashSet<String>()
        s.add(packageName)
        s.add("moe.shizuku.privileged.api")
        s.add("android")
        s.add("com.android.systemui")
        s.add("com.android.phone")
        s.add("com.android.server.telecom")
        s.add("com.android.providers.telephony")
        s.add("com.android.providers.settings")
        s.add("com.android.incallui")
        s.add("com.google.android.dialer")
        s.add("com.android.dialer")
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let { s.add(it) }
        Settings.Secure.getString(contentResolver, "default_input_method")
            ?.substringBefore('/')?.let { s.add(it) }
        return s
    }

    private fun loadApps() {
        tvCount.text = "Cargando apps…"
        thread {
            val pm = packageManager
            val locked = lockedPackages()
            val skip = setOf("com.android.deskclock", "com.google.android.deskclock")
            val items = pm.getInstalledApplications(0).map { ai ->
                Item(
                    ai.packageName,
                    ai.loadLabel(pm).toString(),
                    (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    ai.packageName in locked,
                    ai.packageName in skip
                )
            }.sortedBy { it.label.lowercase() }
            runOnUiThread {
                all.clear()
                all.addAll(items)
                selected.retainAll(items.filter { !it.locked }.map { it.pkg }.toSet())
                applyFilter()
            }
        }
    }

    private fun applyFilter() {
        shown.clear()
        val q = query.trim().lowercase()
        for (i in all) {
            if (filter == 1 && i.system) continue
            if (filter == 2 && !i.system) continue
            if (q.isNotEmpty() && !i.label.lowercase().contains(q) && !i.pkg.lowercase().contains(q)) continue
            shown.add(i)
        }
        adapter.notifyDataSetChanged()
        updateCount()
    }

    private fun updateCount() {
        tvCount.text = "${selected.size} seleccionadas · ${shown.size} en la lista"
    }

    private fun persist() {
        Prefs.sp(this).edit().putStringSet("close_sel", HashSet(selected)).apply()
    }

    private fun selectAll() {
        for (i in shown) if (!i.locked && !i.skipAll) selected.add(i.pkg)
        persist()
        adapter.notifyDataSetChanged()
        updateCount()
    }

    private fun clearAll() {
        for (i in shown) selected.remove(i.pkg)
        persist()
        adapter.notifyDataSetChanged()
        updateCount()
    }

    // ------------------------------------------------------------- Cerrar

    private fun confirmClose() {
        if (closing) return
        if (selected.isEmpty()) {
            Ui.toast(this, "No hay apps seleccionadas")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Cerrar ${selected.size} apps")
            .setMessage(
                "Se cerrarán del todo. No te avisarán nada hasta que las abras de nuevo. " +
                    "Si cierras el reloj, pierdes las alarmas hasta abrirlo otra vez."
            )
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Cerrar") { _, _ -> doClose() }
            .show()
    }

    private fun doClose() {
        closing = true
        btnClose.isEnabled = false
        val pkgs = ArrayList(selected)
        thread {
            val sh = ShellSession()
            var ok = 0
            for ((n, p) in pkgs.withIndex()) {
                runOnUiThread { btnClose.text = "Cerrando ${n + 1}/${pkgs.size}…" }
                if (sh.run("am force-stop $p") != null) ok++
            }
            sh.close()
            runOnUiThread {
                closing = false
                btnClose.isEnabled = true
                btnClose.text = "Cerrar seleccionadas"
                Ui.toast(this, "Listo: $ok de ${pkgs.size} apps cerradas")
            }
        }
    }
}
