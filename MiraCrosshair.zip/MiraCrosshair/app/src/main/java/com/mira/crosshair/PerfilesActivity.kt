package com.mira.crosshair

import android.app.AlertDialog
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.view.View
import android.widget.TextView
import kotlin.concurrent.thread

class PerfilesActivity : GuardedActivity() {

    private lateinit var tvGame: TextView
    private lateinit var tvLast: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(build())
        refreshTexts()
    }

    private fun build(): View {
        val root = Ui.root(this)
        root.addView(Ui.title(this, "Perfiles de rendimiento"))
        root.addView(
            Ui.note(
                this,
                "Cambia entre modos de energía del sistema. No acelera el procesador por encima " +
                    "de sus límites: usa los modos que Android permite."
            )
        )

        root.addView(Ui.section(this, "Juego (para el modo de juego)"))
        tvGame = TextView(this)
        root.addView(tvGame)
        root.addView(Ui.button(this, "Elegir juego") { chooseGame() }, Ui.mw())
        tvLast = TextView(this)
        root.addView(tvLast)

        root.addView(Ui.section(this, "Perfil"))
        root.addView(Ui.button(this, "🔋 Ahorro de batería") { applyProfile(0) }, Ui.mw())
        root.addView(Ui.note(this, "Activa el ahorro de batería de Android."))
        root.addView(Ui.button(this, "⚖️ Predeterminado") { applyProfile(1) }, Ui.mw())
        root.addView(Ui.note(this, "Vuelve a los valores que tenías antes de usar los otros perfiles."))
        root.addView(Ui.button(this, "🚀 Alto rendimiento") { applyProfile(2) }, Ui.mw())
        root.addView(
            Ui.note(
                this,
                "Apaga el ahorro y la batería adaptable, pone el juego elegido en modo de rendimiento " +
                    "y libera RAM. En MIUI el efecto puede ser pequeño."
            )
        )
        return Ui.scroll(this, root)
    }

    private fun refreshTexts() {
        val pkg = Prefs.sp(this).getString("game_pkg", null)
        tvGame.text = if (pkg == null) "Sin juego elegido" else {
            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            "Juego: $label"
        }
        tvLast.text = "Último perfil aplicado: " + (Prefs.sp(this).getString("profile_cur", null) ?: "ninguno")
    }

    private fun chooseGame() {
        thread {
            val pm = packageManager
            val apps = pm.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .map { Pair(it.loadLabel(pm).toString(), it.packageName) }
                .sortedBy { it.first.lowercase() }
            runOnUiThread {
                AlertDialog.Builder(this@PerfilesActivity)
                    .setTitle("Elige el juego")
                    .setItems(apps.map { it.first }.toTypedArray()) { _, i ->
                        Prefs.sp(this@PerfilesActivity).edit().putString("game_pkg", apps[i].second).apply()
                        refreshTexts()
                    }
                    .show()
            }
        }
    }

    private fun applyProfile(kind: Int) {
        val game = Prefs.sp(this).getString("game_pkg", null)
        Ui.toast(this, "Aplicando…")
        thread {
            val log = StringBuilder()
            fun step(desc: String, cmd: String) {
                val o = ShizukuHelper.exec(cmd)
                log.append("• ").append(desc).append(": ").append(if (o.isBlank()) "OK" else o).append('\n')
            }
            val name: String
            when (kind) {
                0 -> {
                    name = "Ahorro de batería"
                    SettingsBackup.saveOrig(this, "global", "low_power")
                    step("Ahorro de batería activado", "settings put global low_power 1")
                }
                1 -> {
                    name = "Predeterminado"
                    log.append("• ").append(SettingsBackup.restore(this, "global", "low_power", "0")).append('\n')
                    log.append("• ")
                        .append(SettingsBackup.restore(this, "global", "adaptive_battery_management_enabled", null))
                        .append('\n')
                    if (game != null) step("Modo de juego estándar", "cmd game mode standard $game")
                }
                else -> {
                    name = "Alto rendimiento"
                    SettingsBackup.saveOrig(this, "global", "low_power")
                    SettingsBackup.saveOrig(this, "global", "adaptive_battery_management_enabled")
                    step("Ahorro de batería apagado", "settings put global low_power 0")
                    step("Batería adaptable apagada", "settings put global adaptive_battery_management_enabled 0")
                    if (game != null) {
                        step("Modo de juego: rendimiento", "cmd game mode performance $game")
                    } else {
                        log.append("• Sin juego elegido: no se cambió el modo de juego\n")
                    }
                    step("Liberar RAM", "am kill-all")
                }
            }
            Prefs.sp(this).edit().putString("profile_cur", name).apply()
            runOnUiThread {
                refreshTexts()
                AlertDialog.Builder(this@PerfilesActivity)
                    .setTitle(name)
                    .setMessage(log.toString())
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }
}
