package com.mira.crosshair

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

data class CrosshairConfig(
    val color: Int = Color.GREEN,
    val alpha: Int = 220,     // 0..255
    val sizeDp: Int = 10,
    val thickDp: Int = 2,
    val style: Int = 1,
    val dx: Int = 0,          // desplazamiento en px desde el centro
    val dy: Int = 0
)

object Prefs {
    private const val FILE = "mira_prefs"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(c: Context): CrosshairConfig {
        val s = sp(c)
        val d = CrosshairConfig()
        return CrosshairConfig(
            color = s.getInt("color", d.color) or 0xFF000000.toInt(),
            alpha = s.getInt("alpha", d.alpha),
            sizeDp = s.getInt("size", d.sizeDp),
            thickDp = s.getInt("thick", d.thickDp),
            style = s.getInt("style", d.style),
            dx = s.getInt("dx", d.dx),
            dy = s.getInt("dy", d.dy)
        )
    }

    fun save(c: Context, cfg: CrosshairConfig) {
        sp(c).edit()
            .putInt("color", cfg.color)
            .putInt("alpha", cfg.alpha)
            .putInt("size", cfg.sizeDp)
            .putInt("thick", cfg.thickDp)
            .putInt("style", cfg.style)
            .putInt("dx", cfg.dx)
            .putInt("dy", cfg.dy)
            .apply()
    }
}
