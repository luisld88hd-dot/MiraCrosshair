package com.mira.crosshair

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

data class CrosshairConfig(
    val color: Int = Color.GREEN,
    val alpha: Int = 220,
    val sizeDp: Int = 10,
    val thickDp: Int = 2,
    val style: Int = 1,
    val dx: Int = 0,
    val dy: Int = 0
)

/** Números de FPS: posición absoluta desde la esquina superior izquierda. */
data class FpsCfg(
    val color: Int = Color.GREEN,
    val alpha: Int = 255,
    val sizeSp: Int = 28,
    val x: Int = 40,
    val y: Int = 40
)

/** Panel de detalles. scale en %, bgAlpha 0..255. */
data class DetCfg(
    val scale: Int = 100,
    val bgAlpha: Int = 170,
    val x: Int = 40,
    val y: Int = 140
)

object Prefs {
    private const val FILE = "mira_prefs"
    val CROSS_KEYS = setOf("color", "alpha", "size", "thick", "style", "dx", "dy")

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun flag(c: Context, key: String) = sp(c).getBoolean(key, false)
    fun setFlag(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()

    fun load(c: Context): CrosshairConfig {
        val s = sp(c)
        val d = CrosshairConfig()
        return CrosshairConfig(
            color = s.getInt("color", d.color) or 0xFF000000.toInt(),
            alpha = s.getInt("alpha", d.alpha),
            sizeDp = s.getInt("size", d.sizeDp),
            thickDp = s.getInt("thick", d.thickDp),
            style = s.getInt("style", d.style),
            dx = s.getInt("dx", d.dx),
            dy = s.getInt("dy", d.dy)
        )
    }

    fun save(c: Context, cfg: CrosshairConfig) {
        sp(c).edit()
            .putInt("color", cfg.color).putInt("alpha", cfg.alpha)
            .putInt("size", cfg.sizeDp).putInt("thick", cfg.thickDp)
            .putInt("style", cfg.style).putInt("dx", cfg.dx).putInt("dy", cfg.dy)
            .apply()
    }

    fun loadFps(c: Context): FpsCfg {
        val s = sp(c)
        val d = FpsCfg()
        return FpsCfg(
            color = s.getInt("fps_color", d.color) or 0xFF000000.toInt(),
            alpha = s.getInt("fps_alpha", d.alpha),
            sizeSp = s.getInt("fps_size", d.sizeSp),
            x = s.getInt("fps_x", d.x),
            y = s.getInt("fps_y", d.y)
        )
    }

    fun saveFps(c: Context, f: FpsCfg) {
        sp(c).edit()
            .putInt("fps_color", f.color).putInt("fps_alpha", f.alpha)
            .putInt("fps_size", f.sizeSp).putInt("fps_x", f.x).putInt("fps_y", f.y)
            .apply()
    }

    fun loadDet(c: Context): DetCfg {
        val s = sp(c)
        val d = DetCfg()
        return DetCfg(
            scale = s.getInt("det_scale", d.scale),
            bgAlpha = s.getInt("det_bg", d.bgAlpha),
            x = s.getInt("det_x", d.x),
            y = s.getInt("det_y", d.y)
        )
    }

    fun saveDet(c: Context, f: DetCfg) {
        sp(c).edit()
            .putInt("det_scale", f.scale).putInt("det_bg", f.bgAlpha)
            .putInt("det_x", f.x).putInt("det_y", f.y)
            .apply()
    }
}

/** Guarda el valor original de un ajuste del sistema antes de cambiarlo, para poder restaurarlo. */
object SettingsBackup {
    private fun k(ns: String, key: String) = "orig_${ns}_$key"

    fun saveOrig(c: Context, ns: String, key: String) {
        val sp = Prefs.sp(c)
        if (!sp.contains(k(ns, key))) {
            sp.edit().putString(k(ns, key), ShizukuHelper.getSetting(ns, key)).apply()
        }
    }

    /** Devuelve un texto con lo que se hizo. [fallback] se usa si no había valor guardado. */
    fun restore(c: Context, ns: String, key: String, fallback: String?): String {
        val sp = Prefs.sp(c)
        val orig = sp.getString(k(ns, key), null) ?: fallback ?: return "$key: sin cambios que restaurar"
        val out = if (orig == "null") {
            ShizukuHelper.exec("settings delete $ns $key")
        } else {
            ShizukuHelper.exec("settings put $ns $key $orig")
        }
        sp.edit().remove(k(ns, key)).apply()
        val shown = if (orig == "null") "valor del sistema" else orig
        return if (out.isBlank()) "$key restaurado ($shown)" else "$key: $out"
    }
}
