package com.mira.crosshair

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Spinner

class CrosshairActivity : GuardedActivity() {

    private var cfg = CrosshairConfig()
    private lateinit var preview: CrosshairView
    private lateinit var btnToggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Prefs.load(this)
        setContentView(build())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        btnToggle.text = if (CrosshairService.running) "APAGAR MIRA" else "ENCENDER MIRA"
    }

    private fun update(n: CrosshairConfig) {
        cfg = n
        Prefs.save(this, n)
        preview.config = n
    }

    private fun toggle() {
        if (CrosshairService.running) {
            stopService(Intent(this, CrosshairService::class.java))
            CrosshairService.running = false
        } else {
            if (!Ui.ensureOverlay(this)) return
            startForegroundService(Intent(this, CrosshairService::class.java))
            CrosshairService.running = true
        }
        refresh()
    }

    private fun build(): View {
        val root = Ui.root(this)
        root.addView(Ui.title(this, "Mira (crosshair)"))
        btnToggle = Ui.button(this, "") { toggle() }.apply { textSize = 18f }
        root.addView(btnToggle, Ui.mw())

        root.addView(Ui.section(this, "Vista previa"))
        val box = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#2B2B2B")) }
        preview = CrosshairView(this).apply { config = cfg }
        box.addView(
            preview,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        root.addView(box, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 160)))

        root.addView(Ui.section(this, "Estilo"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, CrosshairView.STYLE_NAMES
        )
        spinner.setSelection(cfg.style)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != cfg.style) update(cfg.copy(style = pos))
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner, Ui.mw())
        Ui.slider(this, root, "Tamaño (dp)", 2, 60, cfg.sizeDp) { update(cfg.copy(sizeDp = it)) }
        Ui.slider(this, root, "Grosor (dp)", 1, 12, cfg.thickDp) { update(cfg.copy(thickDp = it)) }

        root.addView(Ui.section(this, "Color y transparencia"))
        Ui.colorPicker(this, root, cfg.color) { update(cfg.copy(color = it)) }
        Ui.slider(this, root, "Opacidad", 10, 100, cfg.alpha * 100 / 255, { "$it%" }) {
            update(cfg.copy(alpha = it * 255 / 100))
        }

        root.addView(Ui.section(this, "Posición (desde el centro)"))
        val half = maxOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels) / 2
        Ui.positionBlock(this, root, cfg.dx, cfg.dy, -half, half, Pair(0, 0)) { x, y ->
            update(cfg.copy(dx = x, dy = y))
        }
        return Ui.scroll(this, root)
    }
}
