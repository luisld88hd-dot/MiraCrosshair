package com.mira.crosshair

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build

object Notif {
    private const val CHANNEL = "mira"

    fun build(ctx: Context, title: String, stopIntent: Intent): Notification {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Mira activa", NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(ctx, 1, stopIntent, flags)
        val action = Notification.Action.Builder(
            Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel),
            "Apagar", stop
        ).build()
        return Notification.Builder(ctx, CHANNEL)
            .setContentTitle(title)
            .setContentText("Toca para configurar")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .addAction(action)
            .setOngoing(true)
            .build()
    }

    fun start(s: Service, id: Int, n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            s.startForeground(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            s.startForeground(id, n)
        }
    }
}
