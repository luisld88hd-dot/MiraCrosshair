package com.mira.crosshair

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button

class MonitorActivity : GuardedActivity() {

    private var fps = FpsCfg()
    private var det = DetCfg()
    private lateinit var btnFps: Button
    private lateinit var btnDet: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fps = Prefs.loadFps(this)
        det = Prefs.loadDet(this)
        setContentView(build())
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
    }

    private fun setFps(n: FpsCfg) {
        fps = n
        Prefs.saveFps(this, n)
    }

    private fun setDet(n: DetCfg) {
        det = n
        Prefs.saveDet(this, n)
    }

    private fun refreshButtons() {
        if (!MonitorService.running) {
            Prefs.setFlag(this, "fps_on", false)
            Prefs.setFlag(this, "det_on", false)
        }
        btnFps.text = if (Prefs.flag(this, "fps_on"))
            "FPS: ENCENDIDO (toca para apagar)" else "FPS: APAGADO (toca para encender)"
        btnDet.text = if (Prefs.flag(this, "det_on"))
            "Más detalles: ENCENDIDO (toca para apagar)" else "Más detalles: APAGADO (toca para encender)"
    }

    private fun toggle(key: String) {
        val on = Prefs.flag(this, key)
        if (!on && !Ui.ensureOverlay(this)) return
        Prefs.setFlag(this, key, !on)
        if (Prefs.flag(this, "fps_on") || Prefs.flag(this, "det_on")) {
            MonitorService.running = true
            startForegroundService(Intent(this, MonitorService::class.java))
        }
        refreshButtons()
    }

    private fun build(): View {
        val root = Ui.root(this)
        val dm = resources.displayMetrics
        val maxPx = maxOf(dm.widthPixels, dm.heightPixels)

        root.addView(Ui.title(this, "FPS y rendimiento"))
        root.addView(
            Ui.note(
                this,
                "Solo se mide mientras un panel esté encendido. Si ambos están apagados no se hace nada. " +
                    "Los FPS y el jank son aproximados y salen del juego que tengas en pantalla."
            )
        )

        // ---- Número de FPS
        root.addView(Ui.section(this, "Número de FPS"))
        btnFps = Ui.button(this, "") { toggle("fps_on") }
        root.addView(btnFps, Ui.mw())
        Ui.slider(this, root, "Tamaño (sp)", 10, 90, fps.sizeSp) { setFps(fps.copy(sizeSp = it)) }
        Ui.colorPicker(this, root, fps.color) { setFps(fps.copy(color = it)) }
        Ui.slider(this, root, "Opacidad", 20, 100, fps.alpha * 100 / 255, { "$it%" }) {
            setFps(fps.copy(alpha = it * 255 / 100))
        }
        Ui.positionBlock(this, root, fps.x, fps.y, 0, maxPx, Pair(40, 40)) { x, y ->
            setFps(fps.copy(x = x, y = y))
        }

        // ---- Más detalles
        root.addView(Ui.section(this, "Más detalles"))
        root.addView(
            Ui.note(this, "Muestra FPS, jank, CPU, temperatura de la batería, power (mW), un mini gráfico de FPS y la RAM.")
        )
        btnDet = Ui.button(this, "") { toggle("det_on") }
        root.addView(btnDet, Ui.mw())
        Ui.slider(this, root, "Tamaño del panel", 60, 200, det.scale, { "$it%" }) {
            setDet(det.copy(scale = it))
        }
        Ui.slider(this, root, "Opacidad del fondo", 0, 100, det.bgAlpha * 100 / 255, { "$it%" }) {
            setDet(det.copy(bgAlpha = it * 255 / 100))
        }
        Ui.positionBlock(this, root, det.x, det.y, 0, maxPx, Pair(40, 140)) { x, y ->
            setDet(det.copy(x = x, y = y))
        }

        // ---- Diagnóstico
        root.addView(Ui.section(this, "Diagnóstico de FPS"))
        root.addView(
            Ui.note(
                this,
                "Si los FPS no aparecen: enciende FPS, abre el juego unos segundos, vuelve aquí y toca el botón. " +
                    "Copia el informe y mándalo para ajustar el método."
            )
        )
        root.addView(Ui.button(this, "Ver diagnóstico") { showDiag() }, Ui.mw())
        return Ui.scroll(this, root)
    }

    private fun showDiag() {
        val text = Diag.text
        AlertDialog.Builder(this)
            .setTitle("Diagnóstico de FPS")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .setNeutralButton("Copiar") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("diagnostico", text))
                Ui.toast(this, "Copiado")
            }
            .show()
    }
}
