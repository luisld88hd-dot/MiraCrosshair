package com.mira.crosshair

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/**
 * Una sola shell de Shizuku que se reutiliza para varios comandos seguidos.
 * Evita crear un proceso nuevo en cada medición.
 */
class ShellSession {
    @Volatile private var p: Process? = null
    private var w: OutputStreamWriter? = null
    private var r: BufferedReader? = null

    @Synchronized
    fun run(cmd: String): String? {
        try {
            if (p == null) {
                val np = ShizukuHelper.spawn(arrayOf("sh"))
                p = np
                w = OutputStreamWriter(np.outputStream)
                r = BufferedReader(InputStreamReader(np.inputStream))
                w!!.write("exec 2>&1\n")
            }
            val ww = w!!
            val rr = r!!
            ww.write(cmd)
            ww.write("\necho ")
            ww.write(END)
            ww.write("\n")
            ww.flush()
            val sb = StringBuilder()
            while (true) {
                val line = rr.readLine()
                if (line == null) {
                    close()
                    return null
                }
                if (line == END) break
                sb.append(line).append('\n')
            }
            return sb.toString()
        } catch (e: Throwable) {
            close()
            return null
        }
    }

    /** No toma el candado a propósito: así puede desbloquear una lectura colgada. */
    fun close() {
        val pp = p
        p = null
        w = null
        r = null
        try {
            pp?.destroy()
        } catch (e: Throwable) {
        }
    }

    companion object {
        private const val END = "__MIRA_END__"
    }
}
