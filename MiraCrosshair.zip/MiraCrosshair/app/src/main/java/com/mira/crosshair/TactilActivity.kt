package com.mira.crosshair

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.concurrent.thread

class TactilActivity : GuardedActivity() {

    private val longVals = listOf(100, 150, 200, 250, 300, 350, 400, 450, 500)
    private val multiVals = listOf(20, 40, 60, 80, 90, 100, 120, 140, 160, 180)

    private lateinit var tvLong: TextView
    private lateinit var tvMulti: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(build())
    }

    override fun onResume() {
        super.onResume()
        refreshCurrent()
    }

    private fun grid(parent: LinearLayout, values: List<Int>, onPick: (Int) -> Unit) {
        val g = GridLayout(this).apply { columnCount = 3 }
        for (v in values) {
            val b = Button(this).apply {
                text = "$v ms"
                setOnClickListener { onPick(v) }
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            )
            lp.width = 0
            g.addView(b, lp)
        }
        parent.addView(g, Ui.mw())
    }

    private fun build(): View {
        val root = Ui.root(this)
        root.addView(Ui.title(this, "Táctil"))
        root.addView(
            Ui.warn(
                this,
                "Estos ajustes afectan a TODO el sistema, no solo al juego. Cierra y vuelve a abrir el juego " +
                    "para notar el cambio. Si algo queda raro, usa «Restaurar»."
            )
        )

        // ---- Velocidad de respuesta táctil
        root.addView(Ui.section(this, "Velocidad de respuesta táctil"))
        root.addView(Ui.note(this, "Tiempo que mantienes el dedo para que cuente como pulsación larga (long_press_timeout)."))
        root.addView(
            Ui.warn(
                this,
                "⚠️ Si tu celular es de gama baja, no elijas valores muy bajos: puede no funcionar " +
                    "correctamente y activar menús sin querer."
            )
        )
        tvLong = TextView(this)
        root.addView(tvLong)
        grid(root, longVals) { apply("long_press_timeout", it) }
        root.addView(Ui.button(this, "Restaurar valor original") { restore("long_press_timeout") }, Ui.mw())

        // ---- Multi toque
        root.addView(Ui.section(this, "Multi toque"))
        root.addView(Ui.note(this, "Margen de tiempo entre toques seguidos para que cuenten como varios (multi_press_timeout)."))
        root.addView(
            Ui.warn(
                this,
                "⚠️ Si tu celular es de gama baja, no elijas valores muy bajos: puede no detectar bien " +
                    "los toques dobles y fallar."
            )
        )
        tvMulti = TextView(this)
        root.addView(tvMulti)
        grid(root, multiVals) { apply("multi_press_timeout", it) }
        root.addView(Ui.button(this, "Restaurar valor original") { restore("multi_press_timeout") }, Ui.mw())

        return Ui.scroll(this, root)
    }

    private fun refreshCurrent() {
        thread {
            val l = ShizukuHelper.getSetting("secure", "long_press_timeout")
            val m = ShizukuHelper.getSetting("secure", "multi_press_timeout")
            runOnUiThread {
                tvLong.text = "Valor actual: " + fmt(l)
                tvMulti.text = "Valor actual: " + fmt(m)
            }
        }
    }

    private fun fmt(v: String) = if (v == "null" || v.isBlank()) "predeterminado del sistema" else "$v ms"

    private fun apply(key: String, v: Int) {
        thread {
            SettingsBackup.saveOrig(this, "secure", key)
            val out = ShizukuHelper.exec("settings put secure $key $v")
            runOnUiThread {
                Ui.toast(
                    this,
                    if (out.isBlank()) "Aplicado: $v ms. Cierra y abre el juego para notar el cambio." else out
                )
                refreshCurrent()
            }
        }
    }

    private fun restore(key: String) {
        thread {
            val msg = SettingsBackup.restore(this, "secure", key, null)
            runOnUiThread {
                Ui.toast(this, msg)
                refreshCurrent()
            }
        }
    }
}
