package com.mira.crosshair

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Ayudas para armar pantallas sin XML. */
object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun mw() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    fun root(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 40))
    }

    fun scroll(c: Context, content: View) = ScrollView(c).apply { addView(content) }

    fun title(c: Context, t: String) = TextView(c).apply {
        text = t
        textSize = 24f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, dp(c, 8))
    }

    fun section(c: Context, t: String) = TextView(c).apply {
        text = t
        textSize = 18f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(c, 22), 0, dp(c, 6))
    }

    fun note(c: Context, t: String) = TextView(c).apply {
        text = t
        textSize = 13f
        setTextColor(Color.parseColor("#B0B0B0"))
        setPadding(0, dp(c, 2), 0, dp(c, 6))
    }

    fun warn(c: Context, t: String) = TextView(c).apply {
        text = t
        textSize = 13f
        setTextColor(Color.parseColor("#FFB74D"))
        setPadding(0, dp(c, 2), 0, dp(c, 6))
    }

    fun button(c: Context, t: String, onClick: () -> Unit) = Button(c).apply {
        text = t
        setOnClickListener { onClick() }
    }

    fun toast(c: Context, msg: String) = Toast.makeText(c, msg, Toast.LENGTH_LONG).show()

    /** true si ya hay permiso de superposición; si no, abre los ajustes y devuelve false. */
    fun ensureOverlay(a: Activity): Boolean {
        if (Settings.canDrawOverlays(a)) return true
        toast(a, "Primero da el permiso de superposición y vuelve")
        a.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))
        )
        return false
    }

    class Sld(
        val seek: SeekBar,
        val label: TextView,
        val min: Int,
        val title: String,
        val fmt: (Int) -> String
    ) {
        fun set(v: Int) {
            seek.progress = v - min
            label.text = "$title: ${fmt(v)}"
        }
    }

    fun slider(
        c: Context, parent: LinearLayout, title: String, min: Int, max: Int, value: Int,
        fmt: (Int) -> String = { it.toString() },
        onChange: (Int) -> Unit
    ): Sld {
        val label = TextView(c)
        val seek = SeekBar(c)
        seek.max = max - min
        val s = Sld(seek, label, min, title, fmt)
        s.set(value)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val v = progress + min
                label.text = "$title: ${fmt(v)}"
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        parent.addView(label)
        parent.addView(seek, mw())
        return s
    }

    fun colorPicker(c: Context, parent: LinearLayout, initial: Int, onColor: (Int) -> Unit) {
        var cur = initial or 0xFF000000.toInt()
        lateinit var sr: Sld
        lateinit var sg: Sld
        lateinit var sb: Sld

        val swatches = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val colors = listOf(
            Color.GREEN, Color.RED, Color.CYAN, Color.YELLOW,
            Color.WHITE, Color.MAGENTA, Color.rgb(255, 140, 0)
        )
        for (col in colors) {
            val sw = View(c).apply { setBackgroundColor(col) }
            sw.setOnClickListener {
                cur = col
                sr.set(Color.red(col)); sg.set(Color.green(col)); sb.set(Color.blue(col))
                onColor(col)
            }
            val lp = LinearLayout.LayoutParams(0, dp(c, 40), 1f)
            lp.setMargins(dp(c, 3), dp(c, 3), dp(c, 3), dp(c, 3))
            swatches.addView(sw, lp)
        }
        parent.addView(swatches, mw())

        sr = slider(c, parent, "Rojo", 0, 255, Color.red(cur)) {
            cur = Color.rgb(it, Color.green(cur), Color.blue(cur)); onColor(cur)
        }
        sg = slider(c, parent, "Verde", 0, 255, Color.green(cur)) {
            cur = Color.rgb(Color.red(cur), it, Color.blue(cur)); onColor(cur)
        }
        sb = slider(c, parent, "Azul", 0, 255, Color.blue(cur)) {
            cur = Color.rgb(Color.red(cur), Color.green(cur), it); onColor(cur)
        }
    }

    /** Sliders X/Y + botones de ajuste fino de 1 px + restablecer. */
    fun positionBlock(
        c: Context, parent: LinearLayout, x0: Int, y0: Int, min: Int, max: Int,
        home: Pair<Int, Int>, onChange: (Int, Int) -> Unit
    ) {
        var x = x0
        var y = y0
        val sx = slider(c, parent, "Horizontal (px)", min, max, x0) { x = it; onChange(x, y) }
        val sy = slider(c, parent, "Vertical (px)", min, max, y0) { y = it; onChange(x, y) }

        fun nudge(dx: Int, dy: Int) {
            x = (x + dx).coerceIn(min, max)
            y = (y + dy).coerceIn(min, max)
            sx.set(x)
            sy.set(y)
            onChange(x, y)
        }

        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        fun nb(label: String, dx: Int, dy: Int) {
            row.addView(
                button(c, label) { nudge(dx, dy) },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        nb("◀", -1, 0)
        nb("▶", 1, 0)
        nb("▲", 0, -1)
        nb("▼", 0, 1)
        parent.addView(row, mw())
        parent.addView(button(c, "Restablecer posición") {
            x = home.first
            y = home.second
            sx.set(x)
            sy.set(y)
            onChange(x, y)
        }, mw())
    }
}
