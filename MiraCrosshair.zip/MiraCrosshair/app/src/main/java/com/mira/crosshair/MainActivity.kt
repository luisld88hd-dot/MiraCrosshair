package com.mira.crosshair

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var cfg = CrosshairConfig()
    private lateinit var preview: CrosshairView
    private lateinit var btnToggle: Button
    private lateinit var tvOverlay: TextView
    private lateinit var tvShizuku: TextView

    private class Sld(
        val seek: SeekBar,
        val label: TextView,
        val min: Int,
        val title: String,
        val fmt: (Int) -> String
    ) {
        fun set(v: Int) {
            seek.progress = v - min
            label.text = "$title: ${fmt(v)}"
        }
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Prefs.load(this)
        setContentView(buildUi())
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun update(n: CrosshairConfig) {
        cfg = n
        Prefs.save(this, n)
        preview.config = n
    }

    private fun addSlider(
        parent: LinearLayout, title: String, min: Int, max: Int, value: Int,
        fmt: (Int) -> String = { it.toString() },
        onChange: (Int) -> Unit
    ): Sld {
        val label = TextView(this)
        val seek = SeekBar(this)
        seek.max = max - min
        val s = Sld(seek, label, min, title, fmt)
        s.set(value)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val v = progress + min
                label.text = "$title: ${fmt(v)}"
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        parent.addView(label)
        parent.addView(seek, matchWrap())
        return s
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }

        root.addView(TextView(this).apply {
            text = "Mira Crosshair"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        })

        btnToggle = button("") { toggle() }.apply { textSize = 18f }
        root.addView(btnToggle, matchWrap())

        // ---- Permisos
        root.addView(section("Permisos"))
        tvOverlay = TextView(this)
        root.addView(tvOverlay)
        root.addView(button("Dar permiso de superposición") { requestOverlay() }, matchWrap())
        root.addView(button("Quitar optimización de batería") { requestIgnoreBattery() }, matchWrap())

        // ---- Shizuku
        root.addView(section("Shizuku (evita que el sistema cierre la app)"))
        tvShizuku = TextView(this)
        root.addView(tvShizuku)
        root.addView(button("Abrir Shizuku") { openShizuku() }, matchWrap())
        root.addView(button("Conectar con Shizuku (dar permiso)") { connectShizuku() }, matchWrap())
        root.addView(button("Proteger app ahora") { protectApp() }, matchWrap())

        // ---- Vista previa
        root.addView(section("Vista previa"))
        val box = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#2B2B2B")) }
        preview = CrosshairView(this).apply { config = cfg }
        box.addView(
            preview,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        root.addView(box, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160)))

        // ---- Estilo
        root.addView(section("Estilo"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, CrosshairView.STYLE_NAMES
        )
        spinner.setSelection(cfg.style)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != cfg.style) update(cfg.copy(style = pos))
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner, matchWrap())
        addSlider(root, "Tamaño (dp)", 2, 60, cfg.sizeDp) { update(cfg.copy(sizeDp = it)) }
        addSlider(root, "Grosor (dp)", 1, 12, cfg.thickDp) { update(cfg.copy(thickDp = it)) }

        // ---- Color y transparencia
        root.addView(section("Color y transparencia"))
        lateinit var sr: Sld
        lateinit var sg: Sld
        lateinit var sb: Sld

        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val colors = listOf(
            Color.GREEN, Color.RED, Color.CYAN, Color.YELLOW,
            Color.WHITE, Color.MAGENTA, Color.rgb(255, 140, 0)
        )
        for (c in colors) {
            val sw = View(this).apply { setBackgroundColor(c) }
            sw.setOnClickListener {
                sr.set(Color.red(c)); sg.set(Color.green(c)); sb.set(Color.blue(c))
                update(cfg.copy(color = c))
            }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            swatches.addView(sw, lp)
        }
        root.addView(swatches, matchWrap())

        sr = addSlider(root, "Rojo", 0, 255, Color.red(cfg.color)) {
            update(cfg.copy(color = Color.rgb(it, Color.green(cfg.color), Color.blue(cfg.color))))
        }
        sg = addSlider(root, "Verde", 0, 255, Color.green(cfg.color)) {
            update(cfg.copy(color = Color.rgb(Color.red(cfg.color), it, Color.blue(cfg.color))))
        }
        sb = addSlider(root, "Azul", 0, 255, Color.blue(cfg.color)) {
            update(cfg.copy(color = Color.rgb(Color.red(cfg.color), Color.green(cfg.color), it)))
        }
        addSlider(root, "Opacidad", 10, 100, cfg.alpha * 100 / 255, { "$it%" }) {
            update(cfg.copy(alpha = it * 255 / 100))
        }

        // ---- Posición
        root.addView(section("Posición"))
        val half = maxOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels) / 2
        val sx = addSlider(root, "Horizontal (px)", -half, half, cfg.dx) { update(cfg.copy(dx = it)) }
        val sy = addSlider(root, "Vertical (px)", -half, half, cfg.dy) { update(cfg.copy(dy = it)) }

        fun nudge(ddx: Int, ddy: Int) {
            val n = cfg.copy(
                dx = (cfg.dx + ddx).coerceIn(-half, half),
                dy = (cfg.dy + ddy).coerceIn(-half, half)
            )
            update(n)
            sx.set(n.dx)
            sy.set(n.dy)
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun nudgeBtn(label: String, ddx: Int, ddy: Int) {
            row.addView(button(label) { nudge(ddx, ddy) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        nudgeBtn("◀", -1, 0)
        nudgeBtn("▶", 1, 0)
        nudgeBtn("▲", 0, -1)
        nudgeBtn("▼", 0, 1)
        root.addView(row, matchWrap())
        root.addView(button("Centrar") {
            update(cfg.copy(dx = 0, dy = 0)); sx.set(0); sy.set(0)
        }, matchWrap())

        return ScrollView(this).apply { addView(root) }
    }

    // ------------------------------------------------------- Acciones

    private fun refresh() {
        tvOverlay.text = if (Settings.canDrawOverlays(this))
            "✅ Superposición: permitida" else "❌ Superposición: falta el permiso"
        tvShizuku.text = when (shizukuState()) {
            2 -> "✅ Shizuku: conectado"
            1 -> "⚠️ Shizuku activo, falta dar permiso a esta app"
            else -> "❌ Shizuku: no está activo (ábrelo e inícialo)"
        }
        btnToggle.text = if (CrosshairService.running) "APAGAR MIRA" else "ENCENDER MIRA"
    }

    private fun toggle() {
        if (CrosshairService.running) {
            stopService(Intent(this, CrosshairService::class.java))
            CrosshairService.running = false
        } else {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlay()
                return
            }
            startForegroundService(Intent(this, CrosshairService::class.java))
            CrosshairService.running = true
        }
        refresh()
    }

    private fun requestOverlay() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    @Suppress("BatteryLife")
    private fun requestIgnoreBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Ya está excluida de la optimización de batería")
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun shizukuState(): Int = try {
        when {
            !Shizuku.pingBinder() -> 0
            Shizuku.isPreV11() -> 0
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 2
            else -> 1
        }
    } catch (e: Throwable) {
        0
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i == null) toast("Shizuku no está instalado") else startActivity(i)
    }

    private fun connectShizuku() {
        when (shizukuState()) {
            0 -> toast("Shizuku no está activo. Ábrelo e inícialo (depuración inalámbrica o ADB).")
            1 -> Shizuku.requestPermission(1001)
            else -> toast("Ya está conectado")
        }
    }

    private fun protectApp() {
        if (shizukuState() != 2) {
            toast("Primero conecta con Shizuku")
            return
        }
        toast("Aplicando…")
        thread {
            val out = ShizukuHelper.protect(packageName)
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Resultado")
                    .setMessage(out)
                    .setPositiveButton("OK", null)
                    .show()
                refresh()
            }
        }
    }
}
