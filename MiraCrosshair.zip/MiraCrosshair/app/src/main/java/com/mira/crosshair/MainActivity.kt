package com.mira.crosshair

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.TextView
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var shown = -1
    private var tvOverlay: TextView? = null

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { render() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { render() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { render() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun render() {
        val st = ShizukuHelper.state()
        if (st != shown) {
            shown = st
            tvOverlay = null
            setContentView(if (st == ShizukuHelper.READY) buildMenu() else buildGate(st))
        }
        tvOverlay?.text = if (Settings.canDrawOverlays(this))
            "✅ Superposición: permitida" else "❌ Superposición: falta el permiso"
    }

    // ------------------------------------------------ Pantalla obligatoria de Shizuku

    private fun buildGate(st: Int): View {
        val root = Ui.root(this)
        root.addView(Ui.title(this, "Mira Crosshair"))
        root.addView(
            Ui.warn(
                this,
                if (st == ShizukuHelper.NEEDS_PERMISSION)
                    "⚠️ Shizuku está activo, pero falta darle permiso a esta app."
                else
                    "❌ Shizuku no está activo."
            )
        )
        root.addView(
            Ui.note(
                this,
                "Para que la app funcione correctamente hay que activar Shizuku:\n" +
                    "1. Instala Shizuku desde Play Store.\n" +
                    "2. Ábrelo e inícialo (por depuración inalámbrica o ADB).\n" +
                    "3. Vuelve aquí y toca «Dar permiso a esta app»."
            )
        )
        root.addView(Ui.button(this, "Abrir Shizuku") { openShizuku() }, Ui.mw())
        root.addView(Ui.button(this, "Dar permiso a esta app") { connectShizuku() }, Ui.mw())
        return Ui.scroll(this, root)
    }

    // ------------------------------------------------ Menú principal

    private fun open(cls: Class<*>) = startActivity(Intent(this, cls))

    private fun buildMenu(): View {
        val root = Ui.root(this)
        root.addView(Ui.title(this, "Mira Crosshair"))
        root.addView(TextView(this).apply { text = "✅ Shizuku conectado" })
        val ov = TextView(this)
        tvOverlay = ov
        root.addView(ov)

        root.addView(Ui.section(this, "Funciones"))
        root.addView(Ui.button(this, "🎯 Mira (crosshair)") { open(CrosshairActivity::class.java) }, Ui.mw())
        root.addView(Ui.button(this, "📊 FPS y rendimiento") { open(MonitorActivity::class.java) }, Ui.mw())
        root.addView(Ui.button(this, "👆 Táctil") { open(TactilActivity::class.java) }, Ui.mw())
        root.addView(Ui.button(this, "⚡ Perfiles de rendimiento") { open(PerfilesActivity::class.java) }, Ui.mw())
        root.addView(Ui.button(this, "🧹 Liberar RAM") { freeRam() }, Ui.mw())
        root.addView(Ui.button(this, "❌ Cerrar apps (lista)") { open(AppsActivity::class.java) }, Ui.mw())

        root.addView(Ui.section(this, "Permisos y protección"))
        root.addView(Ui.button(this, "Dar permiso de superposición") { requestOverlay() }, Ui.mw())
        root.addView(Ui.button(this, "Quitar optimización de batería") { requestIgnoreBattery() }, Ui.mw())
        root.addView(Ui.button(this, "Proteger app ahora (evita que la cierren)") { protectApp() }, Ui.mw())
        return Ui.scroll(this, root)
    }

    private fun requestOverlay() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    @Suppress("BatteryLife")
    private fun requestIgnoreBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Ui.toast(this, "Ya está excluida de la optimización de batería")
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i == null) Ui.toast(this, "Shizuku no está instalado. Instálalo desde Play Store.")
        else startActivity(i)
    }

    private fun connectShizuku() {
        when (ShizukuHelper.state()) {
            ShizukuHelper.NOT_RUNNING ->
                Ui.toast(this, "Shizuku no está activo. Ábrelo e inícialo (depuración inalámbrica o ADB).")
            ShizukuHelper.NEEDS_PERMISSION -> Shizuku.requestPermission(1001)
            else -> render()
        }
    }

    private fun protectApp() {
        Ui.toast(this, "Aplicando…")
        thread {
            val out = ShizukuHelper.protect(packageName)
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Resultado")
                    .setMessage(out)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun freeMb(): Long {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem / 1048576L
    }

    private fun freeRam() {
        Ui.toast(this, "Liberando RAM…")
        thread {
            val before = freeMb()
            val out = ShizukuHelper.exec("am kill-all")
            Thread.sleep(1500)
            val after = freeMb()
            runOnUiThread {
                Ui.toast(
                    this,
                    "RAM libre: $before MB → $after MB" + if (out.isNotBlank()) "\n$out" else ""
                )
            }
        }
    }
}
