package com.mira.crosshair

import android.app.Activity

/** Pantallas que solo funcionan con Shizuku listo: si se pierde, vuelven a la pantalla de inicio. */
open class GuardedActivity : Activity() {
    override fun onResume() {
        super.onResume()
        if (ShizukuHelper.state() != ShizukuHelper.READY) finish()
    }
}
