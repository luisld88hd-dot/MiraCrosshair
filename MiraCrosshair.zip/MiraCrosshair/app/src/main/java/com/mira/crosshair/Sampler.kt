package com.mira.crosshair

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

/** Último informe de la medición, para el botón de diagnóstico. */
object Diag {
    @Volatile var text: String =
        "Sin datos todavía. Enciende FPS, abre el juego unos segundos y vuelve aquí."
}

class Sample(
    val fps: Int,          // -1 = no disponible
    val jank: Int,         // -1 = no disponible
    val cpu: Int,
    val tempC: Float,
    val powerMw: Int,
    val battPct: Int,
    val charging: Boolean,
    val ramUsedMb: Int,
    val ramTotalMb: Int,
    val approx: Boolean    // true = FPS estimados con el contador global
)

/**
 * Mide FPS con varios métodos de Android (todos por Shizuku):
 *  1) Capa del juego: dumpsys SurfaceFlinger --latency (exacto, da FPS y jank).
 *  2) Contador global de cuadros: service call SurfaceFlinger 1013 (aproximado, sin jank).
 * Solo existe mientras hay un panel encendido.
 */
class Sampler(private val ctx: Context) {
    private val shell = ShellSession()
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val mi = ActivityManager.MemoryInfo()
    private val battFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
    private val rxOffset = Regex("0x[0-9a-fA-F]+:")
    private val rxHex8 = Regex("[0-9a-fA-F]{8}")

    private var tick = 0
    private var pkg = ""
    private var chosen: String? = null
    private var badStreak = 0
    private var prevLast = 0L
    private var prevIdle = 0L
    private var prevTotal = 0L
    private var lastListTick = -100
    private var prevCounter = -1L
    private var prevCounterNs = 0L

    // datos para el diagnóstico
    private var method = 0
    private var focusRaw = ""
    private var probeInfo = "Sin sondeo todavía"
    private var latHead = ""
    private var globalRaw = ""

    fun close() = shell.close()

    private fun esc(s: String) = s.replace("'", "'\\''")

    fun sample(needDetails: Boolean): Sample {
        if (tick % 5 == 0) refreshForeground()
        tick++

        val useFg = pkg.isNotEmpty() && pkg != ctx.packageName
        if (useFg && chosen == null && tick - lastListTick >= 3) {
            lastListTick = tick
            resolveLayer()
        }
        val layer = if (useFg) chosen else null

        val cmd = StringBuilder()
        if (needDetails) cmd.append("echo @@C; head -n1 /proc/stat; ")
        if (layer != null) {
            cmd.append("echo @@L; dumpsys SurfaceFlinger --latency '").append(esc(layer)).append("'; ")
        }
        if (layer == null || badStreak > 0) {
            cmd.append("echo @@G; service call SurfaceFlinger 1013; ")
        }
        cmd.append("echo @@E")
        val out = shell.run(cmd.toString())

        var fps = -1
        var jank = -1
        var approx = false
        var cpu = 0
        method = 0
        if (out != null) {
            if (needDetails) {
                val st = section(out, "@@C")
                if (st != null) cpu = parseCpu(st)
            }
            val lat = section(out, "@@L")
            if (lat != null) {
                latHead = lat.trim().split('\n').take(4).joinToString("\n")
                val r = parseLatency(lat)
                if (r != null) {
                    fps = r[0]
                    jank = r[1]
                    method = 1
                    badStreak = 0
                    prevCounter = -1L
                } else {
                    badStreak++
                    if (badStreak >= 3) {
                        badStreak = 0
                        chosen = null
                    }
                }
            }
            if (fps < 0) {
                val g = section(out, "@@G")
                if (g != null) {
                    globalRaw = g.trim().take(200)
                    val c = parseCounter(g)
                    if (c >= 0) {
                        val now = System.nanoTime()
                        if (prevCounter in 0..c && now > prevCounterNs) {
                            fps = Math.round((c - prevCounter) * 1e9 / (now - prevCounterNs))
                                .toInt().coerceIn(0, 240)
                            approx = true
                            method = 2
                        }
                        prevCounter = c
                        prevCounterNs = now
                    }
                }
            }
        }

        var temp = 0f
        var mw = 0
        var batt = 0
        var charging = false
        var used = 0
        var total = 0
        if (needDetails) {
            val b = ctx.registerReceiver(null, battFilter)
            if (b != null) {
                temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
                val volt = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
                val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                batt = if (level >= 0 && scale > 0) level * 100 / scale else 0
                val status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                var cur = abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
                if (cur in 1..9999) cur *= 1000   // algunos teléfonos lo dan en mA
                mw = (cur / 1000.0 * volt / 1000.0).toInt()
            }
            am.getMemoryInfo(mi)
            total = (mi.totalMem / 1048576L).toInt()
            used = total - (mi.availMem / 1048576L).toInt()
        }

        Diag.text = "Método: " + when (method) {
            1 -> "capa del juego (SurfaceFlinger --latency)"
            2 -> "contador global (aproximado)"
            else -> "ninguno (sin datos)"
        } + "\nMedición: " + (if (out == null) "la shell de Shizuku no responde" else "shell OK") +
            "\nPaquete en primer plano: " + (if (pkg.isEmpty()) "(no detectado)" else pkg) +
            "\nRespuesta de foco: " + focusRaw +
            "\n" + probeInfo +
            "\nCapa usada: " + (chosen ?: "(ninguna)") +
            "\nPrimeras líneas de latency:\n" + latHead +
            "\nContador global crudo:\n" + globalRaw

        return Sample(fps, jank, cpu, temp, mw, batt, charging, used, total, approx)
    }

    // ---------------------------------------------------------- Primer plano

    private fun parsePkg(s: String?): String {
        if (s == null) return ""
        val i = s.indexOf(" u0 ")
        if (i < 0) return ""
        val st = i + 4
        val e = s.indexOf('/', st)
        return if (e > st) s.substring(st, e) else ""
    }

    private fun refreshForeground() {
        val a = shell.run("dumpsys window | grep -m1 mCurrentFocus")
        var np = parsePkg(a)
        var raw = a?.trim() ?: ""
        if (np.isEmpty()) {
            val b = shell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'")
            np = parsePkg(b)
            raw = (b?.trim() ?: "")
        }
        focusRaw = raw.take(120)
        if (np != pkg) {
            pkg = np
            chosen = null
            badStreak = 0
            prevLast = 0L
            prevCounter = -1L
        }
    }

    // ---------------------------------------------------------- Capas

    /** Lista las capas del juego, prueba cada una y se queda con la que da más cuadros. */
    private fun resolveLayer() {
        val out = shell.run("dumpsys SurfaceFlinger --list | grep -F '$pkg'")
        if (out == null) {
            probeInfo = "No se pudo listar las capas"
            return
        }
        val all = out.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        val ranked = all.sortedBy { n ->
            when {
                n.contains("SurfaceView") && n.contains("BLAST") -> 0
                n.contains("SurfaceView") -> 1
                n.contains("BLAST") -> 2
                else -> 3
            }
        }
        var best: String? = null
        var bestN = 1
        for (name in ranked.take(8)) {
            val o = shell.run("dumpsys SurfaceFlinger --latency '" + esc(name) + "'") ?: continue
            val n = countValid(o)
            if (n > bestN) {
                bestN = n
                best = name
            }
        }
        chosen = best
        badStreak = 0
        prevLast = 0L
        probeInfo = "Capas con el paquete: ${all.size}" +
            (if (all.isNotEmpty()) " (" + all.take(3).joinToString(" | ") + ")" else "") +
            " | elegida: ${best ?: "ninguna"} ($bestN cuadros)"
    }

    private fun countValid(sec: String): Int {
        val lines = sec.split('\n')
        var n = 0
        for (i in 1 until lines.size) {
            val t = secondToken(lines[i])
            if (t > 0L && t != Long.MAX_VALUE) n++
        }
        return n
    }

    // ---------------------------------------------------------- Parseo

    private fun section(out: String, tag: String): String? {
        val s = out.indexOf(tag)
        if (s < 0) return null
        val from = s + tag.length
        val e = out.indexOf("@@", from)
        return if (e < 0) out.substring(from) else out.substring(from, e)
    }

    private fun parseCpu(sec: String): Int {
        val parts = sec.trim().split(' ').filter { it.isNotEmpty() }
        if (parts.size < 6) return 0
        val vals = parts.drop(1).mapNotNull { it.toLongOrNull() }
        if (vals.size < 5) return 0
        val idle = vals[3] + vals[4]
        val total = vals.take(8).sum()
        var cpu = 0
        if (prevTotal > 0) {
            val dT = total - prevTotal
            val dI = idle - prevIdle
            if (dT > 0) cpu = (100 * (dT - dI) / dT).toInt().coerceIn(0, 100)
        }
        prevIdle = idle
        prevTotal = total
        return cpu
    }

    /** Contador global de cuadros: "Result: Parcel(00000000 0000abcd ...)". */
    private fun parseCounter(sec: String): Long {
        val body = sec.replace(rxOffset, "").substringAfter("Parcel(", "").substringBefore("'")
        val toks = rxHex8.findAll(body).map { it.value }.toList()
        if (toks.size < 2) return -1L
        if (toks[0].toLong(16) != 0L) return -1L
        return toks[1].toLong(16)
    }

    /** Devuelve [fps, jank] o null si no hay cuadros. */
    private fun parseLatency(sec: String): IntArray? {
        val lines = sec.split('\n')
        val ts = LongArray(lines.size)
        var n = 0
        for (i in 1 until lines.size) {
            val t = secondToken(lines[i])
            if (t > 0L && t != Long.MAX_VALUE) ts[n++] = t
        }
        if (n < 2) return null
        val last = ts[n - 1]
        if (last == prevLast) return intArrayOf(0, 0)   // sin cuadros nuevos
        prevLast = last

        var j = n - 1
        while (j > 0 && ts[j - 1] >= last - 1_000_000_000L) j--
        val count = n - j
        if (count < 2) return intArrayOf(count, 0)
        val span = last - ts[j]
        val fps = if (span > 0) Math.round((count - 1) * 1e9 / span).toInt().coerceIn(0, 240) else 0

        val d = LongArray(count - 1)
        for (k in 0 until count - 1) d[k] = ts[j + k + 1] - ts[j + k]
        val sorted = d.copyOf()
        sorted.sort()
        val med = sorted[sorted.size / 2]
        var jank = 0
        for (v in d) if (v > med * 3 / 2 && v - med > 4_000_000L) jank++
        return intArrayOf(fps, jank)
    }

    private fun secondToken(line: String): Long {
        var i = 0
        val len = line.length
        while (i < len && line[i].isWhitespace()) i++
        while (i < len && !line[i].isWhitespace()) i++
        while (i < len && line[i].isWhitespace()) i++
        val s = i
        while (i < len && !line[i].isWhitespace()) i++
        if (i == s) return 0L
        return line.substring(s, i).toLongOrNull() ?: 0L
    }
}
