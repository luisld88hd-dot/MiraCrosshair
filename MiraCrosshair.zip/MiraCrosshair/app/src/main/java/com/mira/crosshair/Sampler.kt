package com.mira.crosshair

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

class Sample(
    val fps: Int,          // -1 = no disponible
    val jank: Int,
    val cpu: Int,
    val tempC: Float,
    val powerMw: Int,
    val battPct: Int,
    val charging: Boolean,
    val ramUsedMb: Int,
    val ramTotalMb: Int
)

/**
 * Mide FPS (por SurfaceFlinger, vía Shizuku) y, si se pide, CPU/batería/RAM.
 * Solo existe mientras hay un panel encendido.
 */
class Sampler(private val ctx: Context) {
    private val shell = ShellSession()
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val mi = ActivityManager.MemoryInfo()
    private val battFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)

    private var tick = 0
    private var pkg = ""
    private var candidates: List<String> = emptyList()
    private var candIdx = 0
    private var noFrames = 0
    private var prevLast = 0L
    private var prevIdle = 0L
    private var prevTotal = 0L
    private var lastListTick = -100

    fun close() = shell.close()

    fun sample(needDetails: Boolean): Sample {
        if (tick % 5 == 0) refreshForeground()
        tick++

        val useFg = pkg.isNotEmpty() && pkg != ctx.packageName
        if (useFg && candidates.isEmpty() && tick - lastListTick >= 3) {
            lastListTick = tick
            resolveLayers()
        }
        val layer = if (useFg && candidates.isNotEmpty()) candidates[candIdx % candidates.size] else null

        val cmd = StringBuilder()
        if (needDetails) cmd.append("echo @@C; head -n1 /proc/stat; ")
        if (layer != null) {
            cmd.append("echo @@L; dumpsys SurfaceFlinger --latency '")
                .append(layer.replace("'", "'\\''")).append("'; ")
        }
        cmd.append("echo @@E")
        val out = shell.run(cmd.toString())

        var fps = -1
        var jank = 0
        var cpu = 0
        if (out != null) {
            if (needDetails) {
                val st = section(out, "@@C")
                if (st != null) cpu = parseCpu(st)
            }
            val lat = section(out, "@@L")
            if (lat != null) {
                val r = parseLatency(lat)
                fps = r[0]
                jank = r[1]
            }
        }

        var temp = 0f
        var mw = 0
        var batt = 0
        var charging = false
        var used = 0
        var total = 0
        if (needDetails) {
            val b = ctx.registerReceiver(null, battFilter)
            if (b != null) {
                temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
                val volt = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
                val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                batt = if (level >= 0 && scale > 0) level * 100 / scale else 0
                val status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                var cur = abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
                if (cur in 1..9999) cur *= 1000   // algunos teléfonos lo dan en mA
                mw = (cur / 1000.0 * volt / 1000.0).toInt()
            }
            am.getMemoryInfo(mi)
            total = (mi.totalMem / 1048576L).toInt()
            used = total - (mi.availMem / 1048576L).toInt()
        }
        return Sample(fps, jank, cpu, temp, mw, batt, charging, used, total)
    }

    private fun refreshForeground() {
        val out = shell.run("dumpsys window | grep -m1 mCurrentFocus") ?: return
        val i = out.indexOf(" u0 ")
        var np = ""
        if (i >= 0) {
            val s = i + 4
            val e = out.indexOf('/', s)
            if (e > s) np = out.substring(s, e)
        }
        if (np != pkg) {
            pkg = np
            candidates = emptyList()
            candIdx = 0
            noFrames = 0
            prevLast = 0L
        }
    }

    private fun resolveLayers() {
        val out = shell.run("dumpsys SurfaceFlinger --list | grep -F '$pkg'") ?: return
        val all = out.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        candidates = all.sortedBy { n ->
            when {
                n.contains("SurfaceView") && n.contains("BLAST") -> 0
                n.contains("SurfaceView") -> 1
                n.contains("BLAST") -> 2
                else -> 3
            }
        }
        candIdx = 0
    }

    private fun section(out: String, tag: String): String? {
        val s = out.indexOf(tag)
        if (s < 0) return null
        val from = s + tag.length
        val e = out.indexOf("@@", from)
        return if (e < 0) out.substring(from) else out.substring(from, e)
    }

    private fun parseCpu(sec: String): Int {
        val parts = sec.trim().split(' ').filter { it.isNotEmpty() }
        if (parts.size < 6) return 0
        val vals = parts.drop(1).mapNotNull { it.toLongOrNull() }
        if (vals.size < 5) return 0
        val idle = vals[3] + vals[4]
        val total = vals.take(8).sum()
        var cpu = 0
        if (prevTotal > 0) {
            val dT = total - prevTotal
            val dI = idle - prevIdle
            if (dT > 0) cpu = (100 * (dT - dI) / dT).toInt().coerceIn(0, 100)
        }
        prevIdle = idle
        prevTotal = total
        return cpu
    }

    /** Devuelve [fps, jank]. */
    private fun parseLatency(sec: String): IntArray {
        val lines = sec.split('\n')
        val ts = LongArray(lines.size)
        var n = 0
        for (i in 1 until lines.size) {
            val t = secondToken(lines[i])
            if (t > 0L && t != Long.MAX_VALUE) ts[n++] = t
        }
        if (n < 2) {
            noFrames++
            if (noFrames >= 3) {
                noFrames = 0
                candIdx++
                if (candIdx >= candidates.size) {
                    candidates = emptyList()
                    candIdx = 0
                }
            }
            return intArrayOf(0, 0)
        }
        noFrames = 0
        val last = ts[n - 1]
        if (last == prevLast) return intArrayOf(0, 0)   // sin cuadros nuevos
        prevLast = last

        var j = n - 1
        while (j > 0 && ts[j - 1] >= last - 1_000_000_000L) j--
        val count = n - j
        if (count < 2) return intArrayOf(count, 0)
        val span = last - ts[j]
        val fps = if (span > 0) Math.round((count - 1) * 1e9 / span).toInt().coerceIn(0, 240) else 0

        val d = LongArray(count - 1)
        for (k in 0 until count - 1) d[k] = ts[j + k + 1] - ts[j + k]
        val sorted = d.copyOf()
        sorted.sort()
        val med = sorted[sorted.size / 2]
        var jank = 0
        for (v in d) if (v > med * 3 / 2 && v - med > 4_000_000L) jank++
        return intArrayOf(fps, jank)
    }

    private fun secondToken(line: String): Long {
        var i = 0
        val len = line.length
        while (i < len && line[i].isWhitespace()) i++
        while (i < len && !line[i].isWhitespace()) i++
        while (i < len && line[i].isWhitespace()) i++
        val s = i
        while (i < len && !line[i].isWhitespace()) i++
        if (i == s) return 0L
        return line.substring(s, i).toLongOrNull() ?: 0L
    }
}
