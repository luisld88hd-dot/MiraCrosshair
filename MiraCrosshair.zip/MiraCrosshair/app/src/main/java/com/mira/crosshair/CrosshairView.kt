package com.mira.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class CrosshairView(context: Context) : View(context) {

    companion object {
        val STYLE_NAMES = listOf("Punto", "Cruz", "Cruz con hueco", "Círculo", "Círculo con punto")
    }

    var config: CrosshairConfig = CrosshairConfig()
        set(value) {
            val relayout = value.sizeDp != field.sizeDp || value.thickDp != field.thickDp
            field = value
            if (relayout) requestLayout()
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = ((config.sizeDp * 2 + config.thickDp + 8) * density).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val size = config.sizeDp * density
        val t = config.thickDp * density
        paint.style = Paint.Style.FILL
        paint.color = config.color
        paint.alpha = config.alpha

        when (config.style) {
            0 -> canvas.drawCircle(cx, cy, maxOf(t, size / 4f), paint)
            1 -> {
                canvas.drawRect(cx - size, cy - t / 2, cx + size, cy + t / 2, paint)
                canvas.drawRect(cx - t / 2, cy - size, cx + t / 2, cy + size, paint)
            }
            2 -> {
                val gap = size / 3f
                canvas.drawRect(cx - size, cy - t / 2, cx - gap, cy + t / 2, paint)
                canvas.drawRect(cx + gap, cy - t / 2, cx + size, cy + t / 2, paint)
                canvas.drawRect(cx - t / 2, cy - size, cx + t / 2, cy - gap, paint)
                canvas.drawRect(cx - t / 2, cy + gap, cx + t / 2, cy + size, paint)
            }
            3 -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = t
                canvas.drawCircle(cx, cy, size - t / 2, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = t
                canvas.drawCircle(cx, cy, size - t / 2, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, maxOf(t, size / 8f), paint)
            }
        }
    }
}
