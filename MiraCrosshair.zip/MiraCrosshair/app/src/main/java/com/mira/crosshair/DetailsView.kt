package com.mira.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import java.util.Locale

/** Panel con FPS, jank, CPU, temperatura, power, mini gráfico de FPS y barra de RAM. */
class DetailsView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private var scale = 100
    private var bgAlpha = 170
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val soft = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val hist = IntArray(60)
    private var s: Sample? = null

    init {
        bg.color = Color.BLACK
        tp.color = Color.WHITE
        tp.typeface = Typeface.DEFAULT_BOLD
        line.style = Paint.Style.STROKE
        line.color = Color.GREEN
        soft.color = Color.WHITE
        soft.alpha = 35
    }

    fun setCfg(c: DetCfg) {
        scale = c.scale
        bgAlpha = c.bgAlpha
        requestLayout()
        invalidate()
    }

    fun push(sm: Sample) {
        s = sm
        System.arraycopy(hist, 1, hist, 0, hist.size - 1)
        hist[hist.size - 1] = if (sm.fps > 0) sm.fps else 0
        invalidate()
    }

    private fun unit() = density * scale / 100f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val u = unit()
        setMeasuredDimension((176 * u).toInt(), (142 * u).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val u = unit()
        val w = width.toFloat()
        val h = height.toFloat()
        bg.alpha = bgAlpha
        canvas.drawRoundRect(0f, 0f, w, h, 8 * u, 8 * u, bg)

        val sm = s
        val fpsT = if (sm == null || sm.fps < 0) "--" else sm.fps.toString()
        val jank = sm?.jank ?: 0
        val cpu = sm?.cpu ?: 0
        val temp = String.format(Locale.US, "%.1f", sm?.tempC ?: 0f)
        val mw = sm?.powerMw ?: 0
        val bat = sm?.battPct ?: 0
        val chg = if (sm?.charging == true) " (carga)" else ""

        val pad = 8 * u
        tp.textSize = 13 * u
        var y = pad + 12 * u
        canvas.drawText("FPS $fpsT    Jank $jank", pad, y, tp)
        y += 18 * u
        canvas.drawText("CPU $cpu%    Temp $temp°C", pad, y, tp)
        y += 18 * u
        canvas.drawText("Power $mw mW    Bat $bat%$chg", pad, y, tp)

        // mini gráfico de FPS
        val gt = y + 6 * u
        val gb = gt + 38 * u
        val gl = pad
        val gr = w - pad
        canvas.drawRect(gl, gt, gr, gb, soft)
        var mx = 60
        for (v in hist) if (v > mx) mx = v
        path.reset()
        val step = (gr - gl) / (hist.size - 1)
        for (i in hist.indices) {
            val px = gl + i * step
            val py = gb - (hist[i].toFloat() / mx) * (gb - gt)
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        line.strokeWidth = 1.5f * u
        canvas.drawPath(path, line)

        // barra de RAM
        val used = sm?.ramUsedMb ?: 0
        val total = if ((sm?.ramTotalMb ?: 0) > 0) sm!!.ramTotalMb else 1
        val by = gb + 8 * u
        canvas.drawRoundRect(gl, by, gr, by + 8 * u, 4 * u, 4 * u, soft)
        val ratio = (used.toFloat() / total).coerceIn(0f, 1f)
        bar.color = if (ratio > 0.85f) Color.rgb(255, 112, 67) else Color.rgb(102, 187, 106)
        canvas.drawRoundRect(gl, by, gl + (gr - gl) * ratio, by + 8 * u, 4 * u, 4 * u, bar)
        tp.textSize = 11 * u
        val usedG = String.format(Locale.US, "%.1f", used / 1024f)
        val totG = String.format(Locale.US, "%.1f", total / 1024f)
        val freeG = String.format(Locale.US, "%.1f", (total - used) / 1024f)
        canvas.drawText("RAM $usedG / $totG GB (libre $freeG)", pad, by + 8 * u + 13 * u, tp)
    }
}
