package com.mira.crosshair

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager

class CrosshairService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.mira.crosshair.STOP"
        private const val CHANNEL = "mira"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private var view: CrosshairView? = null
    private var params: WindowManager.LayoutParams? = null

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyConfig() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        showOverlay()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        running = false
        super.onDestroy()
    }

    private fun showOverlay() {
        val cfg = Prefs.load(this)
        val v = CrosshairView(this).apply { config = cfg }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        lp.x = cfg.dx
        lp.y = cfg.dy
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        // Android 12+: una superposición con opacidad > 0.8 bloquea los toques al juego.
        if (Build.VERSION.SDK_INT >= 31) lp.alpha = 0.8f
        wm.addView(v, lp)
        view = v
        params = lp
    }

    private fun applyConfig() {
        val v = view ?: return
        val lp = params ?: return
        val cfg = Prefs.load(this)
        v.config = cfg
        lp.x = cfg.dx
        lp.y = cfg.dy
        runCatching { wm.updateViewLayout(v, lp) }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Mira activa", NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CrosshairService::class.java).setAction(ACTION_STOP), flags
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Apagar", stop
        ).build()
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Mira activa")
            .setContentText("Toca para configurar")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .addAction(action)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }
}
